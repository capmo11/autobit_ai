

require 'rubygems'
require 'watir'
require 'time'
require 'timeout'
require 'net/https'
require 'uri'
require 'Win32API'
require 'auto_click'
require 'json'
require "open-uri"  
require 'watir-nokogiri'


class CoinVolumnBest
  
  def initialize()
    puts "initialize setting!"
     
    
  end
  
  def start
    
    
    

    
       # url = "https://www.bithumb.com/"  
       # doc = Nokogiri::HTML(doc = open(url))
       # puts doc 
       # puts doc.at("#assetRealBTC2KRW")['class']
             
       # puts doc.css("#assetRealBTC2KRW").text
          
        doc = WatirNokogiri::Document.new("https://www.bithumb.com/")
             
        puts doc.span(:id => 'assetRealQTUM2KRW').exists?
        puts doc.text_fields.length
       # <td class="right border_left_none click">
       #   <span class="font_gray" id="assetRealBTG2KRW">(≈ 2,445,769,870 원)
       #   </span>
       # </td>
  end
   
end



doTask = CoinVolumnBest.new() 
doTask.start