require 'rubygems'
require 'watir'
require 'time'
require 'timeout'
require 'net/https'
require 'uri'
require 'Win32API'
require "selenium-webdriver"
#require 'auto_click'
#require 'win32/sound'
require 'open3'
require 'telegram/bot'
require_relative  'KrChartDTO.rb'
#include Win32
#require_relative './CoinDto.rb'
Selenium::WebDriver::Chrome.driver_path = File.join(File.absolute_path('./', "C:/Ruby24-x64/bin/chromedriver.exe"))    

class AutoBit_AI_SignalV2
  
  attr_accessor :server, :loginId, :loginPw, :watir , :bandloop_Cnt , :exceptionCnt , :data , :targetingCoin , :beforeArray  , :nowArray , :beforeTranValue , :nowTranValue  
  attr_accessor :krChartDTO_1Index , :krChartDTO_2Index ,:krChartDTO_3Index ,:krChartDTO_4Index , :krChartDTO_5Index   
  attr_accessor :krChartDTO_before_1Index ,:krChartDTO_before_2Index ,:krChartDTO_before_3Index ,:krChartDTO_before_4Index , :krChartDTO_before_5Index
  attr_accessor :interVal_1 , :interVal_2 , :interVal_3 , :interVal_4 , :interVal_5
  attr_accessor :turnSignal  , :turnSignal_MA
  attr_accessor :signalScore  #7점 이상이면 매수 

  def initialize(loginId,loginPw)
    
    #puts "Current Time : " + time1.inspect
    @loginId = loginId
    @loginPw = loginPw
    @server = 'https://kr.tradingview.com/'
    @watir = Watir::Browser.new :chrome   #:firefox
    @watir.goto "#{@server}"
    @bandloop_Cnt = 0
    @exceptionCnt = 0
    
    #@watir.window.resize_to(600, 700)
    @watir.window.maximize
    sleep(2)
    @beforeArray = {} 
    @nowArray = {}
    @beforeTranValue = {}
    @nowTranValue = {}
    @krChartDTO_before_1Index = KrChartDTO.new
    @krChartDTO_1Index = KrChartDTO.new
    @krChartDTO_before_2Index = KrChartDTO.new
    @krChartDTO_2Index = KrChartDTO.new
    @krChartDTO_before_3Index = KrChartDTO.new
    @krChartDTO_3Index = KrChartDTO.new
    @krChartDTO_before_4Index = KrChartDTO.new
    @krChartDTO_4Index = KrChartDTO.new
    @krChartDTO_before_5Index = KrChartDTO.new
    @krChartDTO_5Index = KrChartDTO.new
    @interVal_1 = 30# 1분   -> 30분
    @interVal_2 = 60# 3분   -> 1시간
    @interVal_3 = 240 # 30분 -> 4시간 
    @interVal_4 = 480 # 60분  -> 8시간 
    @interVal_5 = 1440 #하루
    @interVal_6 = 10080 #일주일
    @turnSignal = -1     # sell 0 buy 1
    @turnSignal_MA = -1 # 이평선 정배열 역배열 문자쏴주기
    @signalScore = 0 
    
      
    puts "initialize setting!"
    #puts '[' +"#{@bandList_Array}".length.to_s   + ']' 
    end

  
    #TOKEN = 'your bot token'
    #id = 'your chat id group or individual'
    #bot = Telegram::Bot::Client.new(TOKEN)
    #bot.api.send_message(chat_id: id, text: "hello world")
    #
    #to send a message without use Telegram::Bot::Client.run(token) do |bot|
    #bot.api.send_message(chat_id: user.chat_id, text: 'Hello, world')
    #end
    
    # telegram api token ->  474059759:AAFM24fbUFVyEhFN6bCszocGgdUqWyJqbxA
    # "https://api.telegram.org/botXXX:YYYY/sendMessage" -d "chat_id=-zzzzzzzzzz&text=my sample text"
    #{"ok":true,"result":[{"update_id":888815941,
    #"message":{"message_id":59,"from":{"id":323422607,"is_bot":false,"first_name":"\uc7ac\ud604","last_name":"\uc591","language_code":"ko"},"chat":{"id":323422607,"first_name":"\uc7ac\ud604","last_name":"\uc591","type":"private"},"date":1519368425,"text":"/start","entities":[{"offset":0,"length":6,"type":"bot_command"}]}}]}
    # https://api.telegram.org/bot474059759:AAFM24fbUFVyEhFN6bCszocGgdUqWyJqbxA/sendmessage?chat_id=323422607&text=good
    # {"ok":true,"result":{"message_id":3,"chat":{"id":-1001364815243,"title":"AutoBit_AI_Signal","username":"AutoBit_AISignal","type":"channel"},"date":1519370562,"text":"good"}}
    # My Auto Token Id : 474059759:AAFM24fbUFVyEhFN6bCszocGgdUqWyJqbxA
  
  

  def krChartLogin
      begin
       puts 'krChartLogin Start'
      @watir.a(:class ,%w(tv-header__link tv-header__link--signin js-header__signin)).click
      @watir.text_field(:name=>'username').value = "#{@loginId}"
      @watir.text_field(:name=>'password').value = "#{@loginPw}"
      #@watir.span(:class ,'tv-button__loader').click
      @watir.button(:class ,%w(tv-button tv-button--no-border-radius tv-button--size_large tv-button--primary_ghost tv-button--loader)).click
      sleep(3)
      @watir.element(:href => '/chart/').hover
      sleep(1)
      @watir.a(:href ,  '/chart/a2YIRud0/').click
      sleep(5) 
      puts "krChartLogin Success"
      return "krChartLogin Success"
      rescue   Exception => e
      puts e.message 
      puts "krChartLogin Fail"
      return "krChartLogin Fail"
      end
  end


  def chartPageLoading
      begin
        while true
          sleep(1) 
          puts 'chartPageLoading...'
          break if @watir.span(:class , 'chart-controls-clock').exists? == true
        end
        
      rescue 
           puts "chartPageLoading Loading Fail..."
           self.chartPageLoading
      end   
    end  
  
    
  def getChartTimeStamp
       begin
         # puts '현재시간 :'+time.hour().to_s+':'+time.min().to_s+':'+time.sec().to_s
         
         
         
         timeSecond = Time.now.strftime("%S").to_s
         timeMinute = Time.now.strftime("%M").to_s
         timeHour = Time.now.strftime("%H").to_s
         
         if ( timeSecond == "40" )
              @watir.refresh
         end
         
          
          if( (timeSecond == "58" && timeMinute == "59" && timeHour == "23" ) ||  (timeSecond == "58" && timeMinute == "59" && timeHour == "07" ) ||  (timeSecond == "58" && timeMinute == "59" && timeHour == "15" )  )
               return "4IndexEnd"
          elsif( (timeSecond == "58" && timeMinute == "59" && timeHour == "23" ) ||  (timeSecond == "58" && timeMinute == "59" && timeHour == "03" ) ||  (timeSecond == "58" && timeMinute == "59" && timeHour == "07" ) ||  (timeSecond == "58" && timeMinute == "59" && timeHour == "11" ) ||  (timeSecond == "58" && timeMinute == "59" && timeHour == "15" ) ||  (timeSecond == "58" && timeMinute == "59" && timeHour == "19" )  )
               return "3IndexEnd"  
           elsif( timeSecond == "58"  && timeMinute == "59"   )
               return "2IndexEnd" 
          elsif( (timeSecond == "58" && timeMinute == "59") ||  (timeSecond == "58" && timeMinute == "29")  )
            return "1IndexEnd"
          elsif( (timeSecond == "58" && timeMinute == "15") ||  (timeSecond == "58" && timeMinute == "29") ||  (timeSecond == "58" && timeMinute == "44")  ||  (timeSecond == "58" && timeMinute == "59")  ) 
            return "15minuteEnd"
          elsif  ( (timeSecond == "58" && timeMinute == "02") ||  (timeSecond == "58" && timeMinute == "05") ||  (timeSecond == "58" && timeMinute == "08")  ||  (timeSecond == "58" && timeMinute == "11")  ||  (timeSecond == "58" && timeMinute == "14")  ||  (timeSecond == "58" && timeMinute == "17")  ||  (timeSecond == "58" && timeMinute == "20")   ||  (timeSecond == "58" && timeMinute == "23")  ||  (timeSecond == "58" && timeMinute == "26")  ||  (timeSecond == "58" && timeMinute == "29")  ||  (timeSecond == "58" && timeMinute == "32") ||  (timeSecond == "58" && timeMinute == "35") ||  (timeSecond == "58" && timeMinute == "38") ||  (timeSecond == "58" && timeMinute == "41") ||  (timeSecond == "58" && timeMinute == "44") ||  (timeSecond == "58" && timeMinute == "47") ||  (timeSecond == "58" && timeMinute == "50") ||  (timeSecond == "58" && timeMinute == "53") ||  (timeSecond == "58" && timeMinute == "56")  ||  (timeSecond == "58" && timeMinute == "59")      )
            return "1minuteEnd"
          elsif  ( timeSecond == "58"  )
            return "1minuteEnd"
           else
            return "StandByTime"    
          end 
       rescue 
            puts "getChartTimeStamp Loading Fail..."
            self.getChartTimeStamp
       end   
     end  
  
    
  def refleshIsOK
    begin
                 
      puts "refleshIsOK...."
      return "refleshIsOK"
    rescue 
      #errorCnt =  errorCnt  + 1
      puts "refleshIsFail..."
      self.refleshIsOK
    end   
  end
    
 def movingAverageStatus(indexValue)
    ##작성중
    begin
      puts 'movingAverageStatus Start'
       sleep(5)
       krChartDTO = KrChartDTO.new
       krChartDTO = krChartDataGetting(indexValue)
       
       
       
       
       nowMovingAverageValue = { "MA5"=>  krChartDTO.get_movingAverage_5().to_f  , "MA20" =>  krChartDTO.get_movingAverage_20().to_f  , "MA60" => krChartDTO.get_movingAverage_60().to_f  , "MA120" =>krChartDTO.get_movingAverage_120().to_f  ,"MA240"  =>  krChartDTO.get_movingAverage_240().to_f  }
       nMvAvgSrtVal = {}  ## nowMovingAverageSortASCValue 
           
       movingAvergaeRank = {}
       countValue = 0    
       nowMovingAverageValue.sort_by {|k,v| v}.reverse.each do |key, value|
             countValue = countValue + 1
             movingAvergaeRank[key] = countValue
             nMvAvgSrtVal[key] = value.to_s
       end
       
       puts 'nowMovingAverageValue'
       puts nowMovingAverageValue
       puts 'movingAvergaeRank...'  
       puts  movingAvergaeRank
       puts 'nMvAvgSrtVal'
       puts nMvAvgSrtVal
       
        puts  movingAvergaeRank["MA5"] == 1 && movingAvergaeRank["MA20"] == 2 && movingAvergaeRank["MA60"] == 3 && movingAvergaeRank["MA120"] == 4  && movingAvergaeRank["MA240"] == 5 #정배열
        puts  movingAvergaeRank["MA5"] == 5 && movingAvergaeRank["MA20"] == 4 && movingAvergaeRank["MA60"] == 3 && movingAvergaeRank["MA120"] == 2  && movingAvergaeRank["MA240"] == 1 #역배열
     
        text = ""
        nowMovingAverageValue.sort_by {|k,v| v}.reverse.each do |key, value|
                text+= key +' : $ '+ value.to_s + '%0d%0a'
        end
        
        puts text
         
         if  (    movingAvergaeRank["MA5"] == 5 && movingAvergaeRank["MA20"] == 4 && movingAvergaeRank["MA60"] == 3 && movingAvergaeRank["MA120"] == 2  && movingAvergaeRank["MA240"] == 1  ) 
             # 역배열상태   0
                uri = URI('https://api.telegram.org/bot474059759:AAFM24fbUFVyEhFN6bCszocGgdUqWyJqbxA/sendmessage?chat_id=-1001364815243&text=(Bithumb '+indexValue.to_s+'Minute  MovingAverage Status)%0d%0aBest Down Signal!! Sad%0d%0a'+text.to_s+'')
                Net::HTTP.get(uri)
                puts 'BEST_DOWN'
                return "BEST_DOWN"
           elsif (  movingAvergaeRank["MA5"] == 1 && movingAvergaeRank["MA20"] == 2 && movingAvergaeRank["MA60"] == 3 && movingAvergaeRank["MA120"] == 4  && movingAvergaeRank["MA240"] == 5  )
              #정배열 상태   1
                 uri = URI('https://api.telegram.org/bot474059759:AAFM24fbUFVyEhFN6bCszocGgdUqWyJqbxA/sendmessage?chat_id=-1001364815243&text=(Bithumb '+indexValue.to_s+'Minute MovingAverage Status)%0d%0aBest Up Signal!! Happy%0d%0a'+text.to_s+'')
                 Net::HTTP.get(uri)
                 puts 'BEST_UP'
                 return "BEST_UP"
                 
           else
              if  (indexValue == @interVal_4 )
                      # 현황 브리핑 
                       uri = URI('https://api.telegram.org/bot474059759:AAFM24fbUFVyEhFN6bCszocGgdUqWyJqbxA/sendmessage?chat_id=-1001364815243&text=(Bithumb '+indexValue.to_s+' MovingAverage Status)%0d%0a'+text.to_s+'')
                       Net::HTTP.get(uri) 
                       puts 'NA'
                       return "NA"
               end
        end    
       
         
         
        rescue
            puts "MovingAverageStatus Fail..."
            self.movingAverageStatus
    end
   
 end   
  
 def krChartDataGettingInit
   begin
      
       uri = URI('https://api.telegram.org/bot474059759:AAFM24fbUFVyEhFN6bCszocGgdUqWyJqbxA/sendmessage?chat_id=-1001364815243&text=Telegram Server initialization... Start..')
       Net::HTTP.get(uri)  
     
     
      @watir.divs(:class ,%w(js-button-text text-1sK7vbvh-))[0].click  # 3분 차트
      chartPageLoading
      sleep(3)
      chartData_Array = @watir.spans(:class => %w(pane-legend-item-value pane-legend-line) ).collect(&:text)
      # 데이터 확인용 #  
       count = 0
       chartData_Array.each do |textValue|
           count = count + 1
          puts textValue+'['+count.to_s+']'
       end
      #End 
        #  :krChartDTO_before_1Index ,:krChartDTO_before_2Index ,:krChartDTO_before_3Index ,:krChartDTO_before_4Index
       
      @krChartDTO_1Index.set_initValue(chartData_Array[0])
      @krChartDTO_1Index.set_highValue(chartData_Array[1]);
      @krChartDTO_1Index.set_lowValue(chartData_Array[2]);
      @krChartDTO_1Index.set_lastValue(chartData_Array[3]);
      @krChartDTO_1Index.set_bollangerCenterValue(chartData_Array[11]);
      @krChartDTO_1Index.set_bollangerHightValue(chartData_Array[12]);
      @krChartDTO_1Index.set_movingAverage_5(chartData_Array[6]);
      @krChartDTO_1Index.set_movingAverage_20(chartData_Array[7]);
      @krChartDTO_1Index.set_movingAverage_60(chartData_Array[8]);
      @krChartDTO_1Index.set_movingAverage_120(chartData_Array[9]);
      @krChartDTO_1Index.set_movingAverage_240(chartData_Array[10]);
      @krChartDTO_1Index.set_stoch_5K3Day_BlueValue(chartData_Array[14]);
      @krChartDTO_1Index.set_stoch_5K3Day_RedValue(chartData_Array[15]);
      @krChartDTO_1Index.set_stoch_12K3Day_BlueValue(chartData_Array[16]);
      @krChartDTO_1Index.set_stoch_12K3Day_RedValue(chartData_Array[17]);
      @krChartDTO_1Index.set_stoch_12K9Day_BlueValue(chartData_Array[18]);
      @krChartDTO_1Index.set_stoch_12K9Day_RedValue(chartData_Array[19]);
      @krChartDTO_1Index.set_stoch_20K12Day_BlueValue(chartData_Array[20]);
      @krChartDTO_1Index.set_stoch_20K12Day_RedValue(chartData_Array[21]);
      buyOrSell_Signal_CalCulate( @krChartDTO_before_1Index  , @krChartDTO_1Index  , @interVal_1)
      
      
      @watir.divs(:class ,%w(js-button-text text-1sK7vbvh-))[1].click  # 30분 차트
      chartPageLoading
      sleep(3)
      chartData_Array = @watir.spans(:class => %w(pane-legend-item-value pane-legend-line) ).collect(&:text)
      # 데이터 확인용 #  
       count = 0
       chartData_Array.each do |textValue|
           count = count + 1
          puts textValue+'['+count.to_s+']'
       end
       
     @krChartDTO_2Index.set_initValue(chartData_Array[0])
     @krChartDTO_2Index.set_highValue(chartData_Array[1]);
     @krChartDTO_2Index.set_lowValue(chartData_Array[2]);
     @krChartDTO_2Index.set_lastValue(chartData_Array[3]);
     @krChartDTO_2Index.set_bollangerCenterValue(chartData_Array[11]);
     @krChartDTO_2Index .set_bollangerHightValue(chartData_Array[12]);
     @krChartDTO_2Index.set_movingAverage_5(chartData_Array[6]);
     @krChartDTO_2Index.set_movingAverage_20(chartData_Array[7]);
     @krChartDTO_2Index.set_movingAverage_60(chartData_Array[8]);
     @krChartDTO_2Index.set_movingAverage_120(chartData_Array[9]);
     @krChartDTO_2Index.set_movingAverage_240(chartData_Array[10]);
     @krChartDTO_2Index.set_stoch_5K3Day_BlueValue(chartData_Array[14]);
     @krChartDTO_2Index.set_stoch_5K3Day_RedValue(chartData_Array[15]);
     @krChartDTO_2Index.set_stoch_12K3Day_BlueValue(chartData_Array[16]);
     @krChartDTO_2Index.set_stoch_12K3Day_RedValue(chartData_Array[17]);
     @krChartDTO_2Index.set_stoch_12K9Day_BlueValue(chartData_Array[18]);
     @krChartDTO_2Index.set_stoch_12K9Day_RedValue(chartData_Array[19]);
     @krChartDTO_2Index.set_stoch_20K12Day_BlueValue(chartData_Array[20]);
     @krChartDTO_2Index.set_stoch_20K12Day_RedValue(chartData_Array[21]);
buyOrSell_Signal_CalCulate( @krChartDTO_before_2Index  , @krChartDTO_2Index  , @interVal_2)
     
     @watir.divs(:class ,%w(js-button-text text-1sK7vbvh-))[2].click  # 1시간 차트
      chartPageLoading
      sleep(3)
      chartData_Array = @watir.spans(:class => %w(pane-legend-item-value pane-legend-line) ).collect(&:text)
      # 데이터 확인용 #  
       count = 0
       chartData_Array.each do |textValue|
           count = count + 1
          puts textValue+'['+count.to_s+']'
       end
     @krChartDTO_3Index.set_initValue(chartData_Array[0])
     @krChartDTO_3Index.set_highValue(chartData_Array[1]);
     @krChartDTO_3Index.set_lowValue(chartData_Array[2]);
     @krChartDTO_3Index.set_lastValue(chartData_Array[3]);
     @krChartDTO_3Index.set_bollangerCenterValue(chartData_Array[11]);
     @krChartDTO_3Index.set_bollangerHightValue(chartData_Array[12]);
     @krChartDTO_3Index.set_movingAverage_5(chartData_Array[6]);
     @krChartDTO_3Index.set_movingAverage_20(chartData_Array[7]);
     @krChartDTO_3Index.set_movingAverage_60(chartData_Array[8]);
     @krChartDTO_3Index.set_movingAverage_120(chartData_Array[9]);
     @krChartDTO_3Index.set_movingAverage_240(chartData_Array[10]);
     @krChartDTO_3Index.set_stoch_5K3Day_BlueValue(chartData_Array[14]);
     @krChartDTO_3Index.set_stoch_5K3Day_RedValue(chartData_Array[15]);
     @krChartDTO_3Index.set_stoch_12K3Day_BlueValue(chartData_Array[16]);
     @krChartDTO_3Index.set_stoch_12K3Day_RedValue(chartData_Array[17]);
     @krChartDTO_3Index.set_stoch_12K9Day_BlueValue(chartData_Array[18]);
     @krChartDTO_3Index.set_stoch_12K9Day_RedValue(chartData_Array[19]);
     @krChartDTO_3Index.set_stoch_20K12Day_BlueValue(chartData_Array[20]);
     @krChartDTO_3Index.set_stoch_20K12Day_RedValue(chartData_Array[21]);
     buyOrSell_Signal_CalCulate( @krChartDTO_before_3Index  , @krChartDTO_3Index  , @interVal_3)
     
     @watir.divs(:class ,%w(js-button-text text-1sK7vbvh-))[3].click  # 4시간 차트
      chartPageLoading
      sleep(3)
      chartData_Array = @watir.spans(:class => %w(pane-legend-item-value pane-legend-line) ).collect(&:text)
      # 데이터 확인용 #  
       count = 0
       chartData_Array.each do |textValue|
           count = count + 1
          puts textValue+'['+count.to_s+']'
       end
     @krChartDTO_4Index.set_initValue(chartData_Array[0])
     @krChartDTO_4Index.set_highValue(chartData_Array[1]);
     @krChartDTO_4Index.set_lowValue(chartData_Array[2]);
     @krChartDTO_4Index.set_lastValue(chartData_Array[3]);
     @krChartDTO_4Index.set_bollangerCenterValue(chartData_Array[11]);
     @krChartDTO_4Index.set_bollangerHightValue(chartData_Array[12]);
     @krChartDTO_4Index.set_movingAverage_5(chartData_Array[6]);
     @krChartDTO_4Index.set_movingAverage_20(chartData_Array[7]);
     @krChartDTO_4Index.set_movingAverage_60(chartData_Array[8]);
     @krChartDTO_4Index.set_movingAverage_120(chartData_Array[9]);
     @krChartDTO_4Index.set_movingAverage_240(chartData_Array[10]);
     @krChartDTO_4Index.set_stoch_5K3Day_RedValue(chartData_Array[14]);
     @krChartDTO_4Index.set_stoch_5K3Day_BlueValue(chartData_Array[15]);
     @krChartDTO_4Index.set_stoch_12K3Day_RedValue(chartData_Array[16]);
     @krChartDTO_4Index.set_stoch_12K3Day_BlueValue(chartData_Array[17]);
     @krChartDTO_4Index.set_stoch_12K9Day_RedValue(chartData_Array[18]);
     @krChartDTO_4Index.set_stoch_12K9Day_BlueValue(chartData_Array[19]);
     @krChartDTO_4Index.set_stoch_20K12Day_RedValue(chartData_Array[20]);
     @krChartDTO_4Index.set_stoch_20K12Day_BlueValue(chartData_Array[21]);
     buyOrSell_Signal_CalCulate( @krChartDTO_before_4Index  , @krChartDTO_4Index  , @interVal_4)
     
    @watir.divs(:class ,%w(js-button-text text-1sK7vbvh-))[4].click  # 8시간 차트
     chartPageLoading
     sleep(3)
     chartData_Array = @watir.spans(:class => %w(pane-legend-item-value pane-legend-line) ).collect(&:text)
     # 데이터 확인용 #  
      count = 0
      chartData_Array.each do |textValue|
          count = count + 1
         puts textValue+'['+count.to_s+']'
      end
    @krChartDTO_4Index.set_initValue(chartData_Array[0])
    @krChartDTO_4Index.set_highValue(chartData_Array[1]);
    @krChartDTO_4Index.set_lowValue(chartData_Array[2]);
    @krChartDTO_4Index.set_lastValue(chartData_Array[3]);
    @krChartDTO_4Index.set_bollangerCenterValue(chartData_Array[11]);
    @krChartDTO_4Index.set_bollangerHightValue(chartData_Array[12]);
    @krChartDTO_4Index.set_movingAverage_5(chartData_Array[6]);
    @krChartDTO_4Index.set_movingAverage_20(chartData_Array[7]);
    @krChartDTO_4Index.set_movingAverage_60(chartData_Array[8]);
    @krChartDTO_4Index.set_movingAverage_120(chartData_Array[9]);
    @krChartDTO_4Index.set_movingAverage_240(chartData_Array[10]);
    @krChartDTO_4Index.set_stoch_5K3Day_RedValue(chartData_Array[14]);
    @krChartDTO_4Index.set_stoch_5K3Day_BlueValue(chartData_Array[15]);
    @krChartDTO_4Index.set_stoch_12K3Day_RedValue(chartData_Array[16]);
    @krChartDTO_4Index.set_stoch_12K3Day_BlueValue(chartData_Array[17]);
    @krChartDTO_4Index.set_stoch_12K9Day_RedValue(chartData_Array[18]);
    @krChartDTO_4Index.set_stoch_12K9Day_BlueValue(chartData_Array[19]);
    @krChartDTO_4Index.set_stoch_20K12Day_RedValue(chartData_Array[20]);
    @krChartDTO_4Index.set_stoch_20K12Day_BlueValue(chartData_Array[21]);
    buyOrSell_Signal_CalCulate(@interVal_5)
     
      
      
      
   rescue 
     
   end
 end  
    
  
  
 def krChartDataGetting(intervalMinute)
   begin
      puts 'intervaleMinute['+intervalMinute.to_s+']'
      if(intervalMinute == @interVal_1 )
        @watir.divs(:class ,%w(js-button-text text-1sK7vbvh-))[0].click  #  1번째 즐겨찾기  차트
      elsif(intervalMinute ==  @interVal_2 )
        @watir.divs(:class ,%w(js-button-text text-1sK7vbvh-))[1].click  # 2번째 즐겨찾기 차트
      elsif(intervalMinute ==  @interVal_3 )
        @watir.divs(:class ,%w(js-button-text text-1sK7vbvh-))[2].click  # 3번째 즐겨찾기 차트
      elsif(intervalMinute ==  @interVal_4 )
        @watir.divs(:class ,%w(js-button-text text-1sK7vbvh-))[3].click  # 4번째 즐겨찾기 차트
      elsif(intervalMinute ==  @interVal_5 )
        @watir.divs(:class ,%w(js-button-text text-1sK7vbvh-))[4].click  # 5번째 즐겨찾기 차트 
      else
        @watir.divs(:class ,%w(js-button-text text-1sK7vbvh-))[0].click  # 기본디폴트   처음 인터발로 설정
      end
      chartPageLoading  
      sleep(1)
      krChartDTO = KrChartDTO.new
      sleep(1)
      ##초기값 셋팅\
      puts '***************************************Start****************************************************'
      chartData_Array = @watir.spans(:class => %w(pane-legend-item-value pane-legend-line) ).collect(&:text)
      puts 'chartData_Array List Count [ '+chartData_Array.length.to_s+ ']'
      
      # 데이터 확인용 #  
      count = -1
      chartData_Array.each do |textValue|
          count = count + 1
         puts textValue+'['+count.to_s+']'
      end
      
      regCnt =  chartData_Array[0].to_s.gsub(/\d/, "") .gsub(".","").length +  chartData_Array[1].to_s.gsub(/\d/, "") .gsub(".","").length +  chartData_Array[2].to_s.gsub(/\d/, "") .gsub(".","").length +  chartData_Array[3].to_s.gsub(/\d/, "") .gsub(".","").length
      regCnt+=  chartData_Array[11].to_s.gsub(/\d/, "") .gsub(".","").length +  chartData_Array[12].to_s.gsub(/\d/, "") .gsub(".","").length +  chartData_Array[6].to_s.gsub(/\d/, "") .gsub(".","").length +  chartData_Array[7].to_s.gsub(/\d/, "") .gsub(".","").length
      regCnt+=  chartData_Array[8].to_s.gsub(/\d/, "") .gsub(".","").length +  chartData_Array[9].to_s.gsub(/\d/, "") .gsub(".","").length +  chartData_Array[10].to_s.gsub(/\d/, "") .gsub(".","").length +  chartData_Array[14].to_s.gsub(/\d/, "") .gsub(".","").length
      regCnt+=  chartData_Array[15].to_s.gsub(/\d/, "") .gsub(".","").length +  chartData_Array[16].to_s.gsub(/\d/, "") .gsub(".","").length +  chartData_Array[17].to_s.gsub(/\d/, "") .gsub(".","").length +  chartData_Array[18].to_s.gsub(/\d/, "") .gsub(".","").length
      regCnt+=  chartData_Array[19].to_s.gsub(/\d/, "") .gsub(".","").length +  chartData_Array[20].to_s.gsub(/\d/, "") .gsub(".","").length +  chartData_Array[21].to_s.gsub(/\d/, "") .gsub(".","").length 
      
      puts 'RegCnt::=>'+ regCnt.to_s
      
      
      if  regCnt > 0 
          # 정규식으로 데이터가 정확하지 않다면 다시 데이터 리딩해서 다시 불러온다.
          self.krChartDataGetting(intervalMinute)
      end  
      
      krChartDTO.set_initValue(chartData_Array[0])
      krChartDTO.set_highValue(chartData_Array[1]);
      krChartDTO.set_lowValue(chartData_Array[2]);
      krChartDTO.set_lastValue(chartData_Array[3]);
      krChartDTO.set_bollangerCenterValue(chartData_Array[11]);
      krChartDTO.set_bollangerHightValue(chartData_Array[12]);
      krChartDTO.set_movingAverage_5(chartData_Array[6]);
      krChartDTO.set_movingAverage_20(chartData_Array[7]);
      krChartDTO.set_movingAverage_60(chartData_Array[8]);
      krChartDTO.set_movingAverage_120(chartData_Array[9]);
      krChartDTO.set_movingAverage_240(chartData_Array[10]);
      krChartDTO.set_stoch_5K3Day_BlueValue(chartData_Array[14]);
      krChartDTO.set_stoch_5K3Day_RedValue(chartData_Array[15]);
      krChartDTO.set_stoch_12K3Day_BlueValue(chartData_Array[16]);
      krChartDTO.set_stoch_12K3Day_RedValue(chartData_Array[17]);
      krChartDTO.set_stoch_12K9Day_BlueValue(chartData_Array[18]);
      krChartDTO.set_stoch_12K9Day_RedValue(chartData_Array[19]);
      krChartDTO.set_stoch_20K12Day_BlueValue(chartData_Array[20]);
      krChartDTO.set_stoch_20K12Day_RedValue(chartData_Array[21]);
      
      return krChartDTO
     
   rescue Exception  => e
   puts "krChartDataGetting...Fail"
   puts e.message 
   self.krChartDataGetting(intervalMinute)
   end
 end 
 
 
     
 def buyOrSell_Signal_CalCulate(krChartDTO_Before_Obj , krChartDTO_Obj , interValMinute )
   begin
              
            
     
     
        ##단타픽
             # 스코어가 총 7점 이상이되야 매수 사인 나가고 7점 이하면 매도임.
          
             # 상승장에서는 5일선이 20일선이 위에에 있으면  상승장
             # 상승장에서는 5일선이 20일선이 아래에 있으면  하락장
             # 스코어 점수 계산법 
             # 양봉일때             1점
             #  5-3-3 상승     1점     
             #  12-3-3 상승   2점
             # 12 -6-6 상승   3점
             # 20-5-5 상승    4점  4점은 저번 타임보다 수치가 높아도 4점 부여  하지만 저번타임보다 낮으면 4점 추가 X 
             # 총 7점 이상되야 매수 , 7점 이하면 매도  하지만 상승장에서는 수치 무의미, 
             
          
             #무조건 매도   
             #::12-6-6  80이상 20-5-5 80이상 2가지 조건 만족하면 풀매도. 
             #:: 최고가 대비 종가가 -1% 이상 빠진 캔들  윗꼬리 음봉 역시 풀매도
             #:: 완벽한 역배열이면  관망.
          
             #무조건매수
             
             
             
              #5일선과 20일선 위에 있는지 아래 있는지 추세 ㅋㅋ   true 상승 false 하락
              stochChSe =  krChartDTO_Obj.get_movingAverage_5().to_f >  krChartDTO_Obj.get_movingAverage_20().to_f
              puts 'stochChSe'
              puts stochChSe
              
              #캔들이 5일선 밑에 있는지 위에 있는지 알아야함  하향선인지 상향선인지 알아봐야함
              stochDanGiChuSe =  krChartDTO_Obj.get_movingAverage_5().to_f  <= krChartDTO_Obj.get_lastValue().to_f
              
             # 양봉인지 음봉인지? 양봉이면 1점 , 음봉이면 -1  true면 양봉 false면 음봉
              candleType =  krChartDTO_Obj.get_initValue().to_f < krChartDTO_Obj.get_lastValue().to_f
              
              if(candleType == true  )
                  puts '양봉인지 음봉인지'
                  @signalScore = @signalScore + 1    # 양봉이면 +1점 
                  puts @signalScore
              end
          
             puts '데이터계산'
          
              # 30분봉 데이터  Score Index Boolean = SIB
              stoch533 =  krChartDTO_Obj.get_stoch_5K3Day_RedValue().to_f        <  krChartDTO_Obj.get_stoch_5K3Day_BlueValue().to_f   
              stoch1233 = krChartDTO_Obj.get_stoch_12K3Day_RedValue().to_f     <  krChartDTO_Obj.get_stoch_12K3Day_BlueValue().to_f
              stoch1299 =  krChartDTO_Obj.get_stoch_12K9Day_RedValue().to_f     <  krChartDTO_Obj.get_stoch_12K9Day_BlueValue().to_f
              stoch201212 = krChartDTO_Obj.get_stoch_20K12Day_RedValue().to_f  <  krChartDTO_Obj.get_stoch_20K12Day_BlueValue().to_f
              stoch201212_ChSe = false
              
              if ( krChartDTO_Before_Obj.get_stoch_20K12Day_BlueValue().to_f  != 0.0)
                  stoch201212_ChSe = krChartDTO_Before_Obj.get_stoch_20K12Day_BlueValue().to_f  <  krChartDTO_Obj.get_stoch_20K12Day_BlueValue().to_f
              end
              
              if ( stoch533 == true ) 
                    @signalScore = @signalScore + 1
                    puts @signalScore
              end
              if ( stoch1233== true  ) 
                    @signalScore = @signalScore + 2
                    puts @signalScore
              end
              if ( stoch1299== true  ) 
                    @signalScore = @signalScore + 3
                    puts @signalScore
              end
              if ( stoch201212 == true  ||  stoch201212_ChSe == true ) 
                    @signalScore = @signalScore + 4
                    puts @signalScore
              end
              
              puts '@signalScore'
              puts @signalScore
              
              
                  if (  @signalScore >= 7 )
                                  puts 'buy SMS'
                                  uri = URI('https://api.telegram.org/bot474059759:AAFM24fbUFVyEhFN6bCszocGgdUqWyJqbxA/sendmessage?chat_id=-1001364815243&text='+interValMinute.to_s+'MinuteBtc_Buy%0d%0aBuyValue=$'+krChartDTO_Obj.get_lastValue().to_s+'%0d%0aFirst_TargetSell=$'+krChartDTO_Obj.get_bollangerCenterValue().to_s+'%0d%0aSecond_TargetSell=$'+krChartDTO_Obj.get_bollangerHightValue().to_s+'')
                                  Net::HTTP.get(uri)
                            elsif(@signalScore < 7)
                                  puts 'Sell SMS'
                                  uri = URI('https://api.telegram.org/bot474059759:AAFM24fbUFVyEhFN6bCszocGgdUqWyJqbxA/sendmessage?chat_id=-1001364815243&text='+interValMinute.to_s+'MinuteBtc_Sell%0d%0aBuyValue=$'+krChartDTO_Obj.get_lastValue().to_s+'%0d%0aFirst_TargetSell=$'+krChartDTO_Obj.get_bollangerCenterValue().to_s+'%0d%0aSecond_TargetSell=$'+krChartDTO_Obj.get_bollangerHightValue().to_s+'')
                                  Net::HTTP.get(uri)
                             else
                                  puts 'StandBy SMS'
                                  uri = URI('https://api.telegram.org/bot474059759:AAFM24fbUFVyEhFN6bCszocGgdUqWyJqbxA/sendmessage?chat_id=-1001364815243&text='+interValMinute.to_s+'MinuteBtc_StandBy Position')
                                  Net::HTTP.get(uri)
                   end
                   
            # 시그널스코어 초기화        
           @signalScore = 0 
              
            #    if ( ( krChartDTO.get_stoch_12K3Day_RedValue().to_i < krChartDTO.get_stoch_12K3Day_BlueValue().to_i ) && krChartDTO.get_stoch_12K3Day_BlueValue().to_i < 30 && ( krChartDTO.get_stoch_12K9Day_RedValue().to_i < krChartDTO.get_stoch_12K9Day_BlueValue().to_i ) && krChartDTO.get_stoch_12K9Day_BlueValue().to_i < 30 )
            #       uri = URI('https://api.telegram.org/bot474059759:AAFM24fbUFVyEhFN6bCszocGgdUqWyJqbxA/sendmessage?chat_id=-1001364815243&text=1IndexBtc_Buy')
            #       Net::HTTP.get(uri)
            #   elsif( ( krChartDTO.get_stoch_12K3Day_RedValue().to_i > krChartDTO.get_stoch_12K3Day_BlueValue().to_i ) && ( krChartDTO.get_stoch_12K9Day_RedValue().to_i < krChartDTO.get_stoch_12K9Day_BlueValue().to_i ) || krChartDTO.get_stoch_12K3Day_BlueValue().to_i > 80  )
            #       uri = URI('https://api.telegram.org/bot474059759:AAFM24fbUFVyEhFN6bCszocGgdUqWyJqbxA/sendmessage?chat_id=-1001364815243&text=1IndexBtc_Sell')
            #       Net::HTTP.get(uri)
            #   else 
            #      uri = URI('https://api.telegram.org/bot474059759:AAFM24fbUFVyEhFN6bCszocGgdUqWyJqbxA/sendmessage?chat_id=-1001364815243&text=1IndexBtc_StandBy')
            #      Net::HTTP.get(uri)
            #   end
     
       if ( interValMinute ==  @interVal_1 )
              puts 'Data Now Instance -> Data Before Instance interVal_1 Transfer... Start!!'
              @krChartDTO_before_1Index =    @krChartDTO_1Index
       elsif( interValMinute == @interVal_2  )
              puts 'Data Now Instance -> Data Before Instance interVal_1 , interVal_2 Transfer... Start!!'
              @krChartDTO_before_1Index =    @krChartDTO_1Index
              @krChartDTO_before_2Index =    @krChartDTO_2Index
       elsif( interValMinute == @interVal_3  )
              puts 'Data Now Instance -> Data Before Instance interVal_1 , interVal_2 , interVal_3 Transfer... Start!!'
              @krChartDTO_before_1Index =    @krChartDTO_1Index
              @krChartDTO_before_2Index =    @krChartDTO_2Index
              @krChartDTO_before_3Index =    @krChartDTO_3Index
       elsif ( interValMinute == @interVal_4  )
              puts 'Data Now Instance -> Data Before Instance interVal_1 , interVal_2 , interVal_3 , interVal_4  Transfer... Start!!'
               @krChartDTO_before_1Index =    @krChartDTO_1Index
               @krChartDTO_before_2Index =    @krChartDTO_2Index
               @krChartDTO_before_3Index =    @krChartDTO_3Index
               @krChartDTO_before_4Index =    @krChartDTO_4Index
       end 
       puts 'Data Now Instance -> Data Before Instance Transfer... End!!'
      
     rescue Exception => e
          puts "buyOrSell_Signal_CalCulate Fail"
          puts e.message 
          uri = URI('https://api.telegram.org/bot474059759:AAFM24fbUFVyEhFN6bCszocGgdUqWyJqbxA/sendmessage?chat_id=-1001364815243&text=Error::%0d%0a'+e.message.to_s+'')
          Net::HTTP.get(uri)
          self.loginDo  
      ensure
      end
 end

  #Naver login logic 
  def loginDo
    begin
      
      krChartLogin # 차트 로그인
      krChartDataGettingInit # 차트 init 셋팅값 설정
      
     #while true
     #          puts '1Index  DataGetting Start'
     #          @krChartDTO_1Index = krChartDataGetting(@interVal_1)
     #           puts '1Index  buyOrSell_Signal_CalCulate Start'
     #           
     #           buyOrSell_Signal_CalCulate(@interVal_1 )
     #           sleep ( 10 )
     #end
      
     # initKrChartDataSetting  ##TODO 만들어야함
      while true
        
        standByTime = ""
        timeStamp =  getChartTimeStamp
        
        if timeStamp != "StandByTime" 
           if ( timeStamp  == "1IndexEnd" )
                      puts '1Index  DataGetting Start'
                     @krChartDTO_1Index = krChartDataGetting(@interVal_1)
                      puts '1Index  buyOrSell_Signal_CalCulate Start'
                      movingAverageStatus(@interVal_1)
                      buyOrSell_Signal_CalCulate(@krChartDTO_before_1Index ,@krChartDTO_1Index,  @interVal_1 )
             elsif (timeStamp  == "2IndexEnd")
                      puts '1Index  and 2Index -> DataGetting Start'
                     @krChartDTO_1Index = krChartDataGetting(@interVal_1)
                     @krChartDTO_2Index = krChartDataGetting(@interVal_2)
                      puts '2Index  buyOrSell_Signal_CalCulate Start'
                      movingAverageStatus(@interVal_1)
                      movingAverageStatus(@interVal_2)
                      buyOrSell_Signal_CalCulate(@krChartDTO_before_1Index ,@krChartDTO_1Index, @interVal_1 )
                      buyOrSell_Signal_CalCulate(@krChartDTO_before_2Index ,@krChartDTO_2Index, @interVal_2 )
             elsif (timeStamp  == "3IndexEnd")
                     puts '1Index  2Index 3Index -> DataGetting Start'
                     @krChartDTO_1Index = krChartDataGetting(@interVal_1)
                     @krChartDTO_2Index = krChartDataGetting(@interVal_2)
                     @krChartDTO_3Index =  krChartDataGetting(@interVal_3)
                     
                     puts '3Index  buyOrSell_Signal_CalCulate Start'
                     movingAverageStatus(@interVal_1)
                     movingAverageStatus(@interVal_2)
                     movingAverageStatus(@interVal_3)
                     buyOrSell_Signal_CalCulate(@krChartDTO_before_1Index ,@krChartDTO_1Index, @interVal_1 )
                     buyOrSell_Signal_CalCulate(@krChartDTO_before_2Index ,@krChartDTO_2Index, @interVal_2 )
                     buyOrSell_Signal_CalCulate(@krChartDTO_before_3Index ,@krChartDTO_3Index, @interVal_3 )
             elsif (timeStamp  == "4IndexEnd")
                      puts '1Index  2Index 3Index 4Index -> DataGetting Start'
                      @krChartDTO_1Index = krChartDataGetting(@interVal_1)
                      @krChartDTO_2Index  = krChartDataGetting(@interVal_2)
                      @krChartDTO_3Index =  krChartDataGetting(@interVal_3)
                      @krChartDTO_4Index =  krChartDataGetting(@interVal_4)
                      puts '4Index  buyOrSell_Signal_CalCulate Start'
                      movingAverageStatus(@interVal_1)
                      movingAverageStatus(@interVal_2)
                      movingAverageStatus(@interVal_3)
                      movingAverageStatus(@interVal_4)
                      buyOrSell_Signal_CalCulate(@krChartDTO_before_1Index ,@krChartDTO_1Index, @interVal_1 )
                      buyOrSell_Signal_CalCulate(@krChartDTO_before_2Index ,@krChartDTO_2Index, @interVal_2 )
                      buyOrSell_Signal_CalCulate(@krChartDTO_before_3Index ,@krChartDTO_3Index, @interVal_3 )
                      buyOrSell_Signal_CalCulate(@krChartDTO_before_4Index ,@krChartDTO_4Index, @interVal_4 )
             elsif (timeStamp  == "5IndexEnd")          
                      puts '1Index  2Index 3Index 4Index  and Status -> DataGetting Start'
                      movingAverageStatus(@interVal_5)
             else 
           end
        end    
     
        
        
        
      end
      
    rescue Exception => e
      puts "loginDo Fail"
      puts e.message 
      uri = URI('https://api.telegram.org/bot474059759:AAFM24fbUFVyEhFN6bCszocGgdUqWyJqbxA/sendmessage?chat_id=-1001364815243&text=Error::%0d%0a'+e.message.to_s+'')
      Net::HTTP.get(uri)
      self.loginDo  
    ensure
    end
  end

  #> require './Phone'  #! import class
  #> myphone = Phone.new  #! instantiate class Phone
  #> myphone.model = "iPhone5"  #! set model name
  #> myphone.model  #! get model name
   


end

doTask = AutoBit_AI_SignalV2.new('capmo1@naver.com','Dnjzm1324!') 
doTask.loginDo

# 새로운 브라우저창 컨트롤
#browser.window(:title => "annoying popup").use do
#  browser.button(:id => "close").click
#end


 ## 차트 로딩 데이터 
   #9826.4[1] 시가
   #9827.0[2] 고가
   #9583.1[3] 저가
   #9758.5[4] 종가
   #14.382K[5] 현재볼륨
   #20.303K[6] 이평선 볼륨
   #10127.3906[7] 5일선
   #10699.0977[8] 20일선
   #9230.7604[9] 60일선
   #10193.9611[10] 120일선
   #12694.8513[11] 240일선
   #[12] 볼린저밴드 중단
   #[13] 볼린저밴드 상단
   #[14] 볼린저밴드 하단
   #11.8492[15] 5 3 3 k 파란선      # 파란선이 빨간선 위에 있을때가 상승추세 
   #15.7167[16] 5 3 3 D 빨간선      # 파란선이 빨간선 아래 있으면 하락추세
   #8.0652[17] 12 3 3 k 파란선
   #14.4781[18] 12 3 3 D 빨간선
   #35.0721[19] 12 9 9 k 파란선
   #64.6244[20] 12 9 9 D 빨간선
   #58.9619[21] 20 12 12 k 파란선
   #80.7940[22] 20 12 12 D 빨간선