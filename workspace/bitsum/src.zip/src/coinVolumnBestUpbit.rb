

require 'rubygems'
require 'watir'
require 'time'
require 'timeout'
require 'net/https'
require 'uri'
#require 'Win32API'
require 'json'
Selenium::WebDriver::Chrome.driver_path = File.join(File.absolute_path('./', "C:/Ruby24-x64/bin/chromedriver.exe"))    
#require 'win32/sound'
#include Win32



class CoinVolumnBest
  
  #TODO 크롬 , 인터넷IE 로직도 추가
   #initialize :: param setting
   attr_accessor :server, :loginId, :loginPw, :watir , :bandloop_Cnt , :exceptionCnt, :beforeTranValue , :nowTranValue  
   
   def initialize()
     time1 = Time.new
     puts "Current Time : " + time1.inspect
     @loginId = loginId
     @loginPw = loginPw
     @server = 'https://upbit.com/exchange?code=CRIX.UPBIT.BTC-OK'
     @watir = Watir::Browser.new :chrome 
     @watir.goto "#{@server}"
     @bandloop_Cnt = 0
     @exceptionCnt = 0
     @beforeTranValue = {}
     @nowTranValue = {}  
     #@watir.window.resize_to(600, 700)
     puts "initialize setting!"
     #puts '[' +"#{@bandList_Array}".length.to_s   + ']' 
   end
   
  def start
    
    
 
   
      
    @watir.goto 'https://upbit.com/exchange?code=CRIX.UPBIT.BTC-OK'
       
    begin
    
      
         
          sleep(10)
                    
          
          #{"스테이터스네트워크토큰\nSNT/KRW"=>1, "에이다\nADA/KRW"=>2, "리플\nXRP/KRW"=>3, "비트코인\nBTC/KRW"=>4, "스텔라루멘\nXLM/KRW"=>5, "뉴이코노미무브먼트\nXEM/KRW"=>6, "스팀\nSTEEM/KRW"=>7, "퀀텀\nQTUM/KRW"=>8, "파워렛저\nPOWR/KRW"=>9, "머큐리\nMER/KRW"=>10, "아인스타이늄\nEMC2/KRW"=>11, "비트코인캐시\nBCC/KRW"=>12, "이더리움\nETH/KRW"=>13, "블록틱스\nTIX/KRW"=>14, "스팀달러\nSBD/KRW"=>15, "코모도\nKMD/KRW"=>16, "그로스톨코인\nGRS/KRW"=>17, "스트라티스\nSTRAT/KRW"=>18, "오미세고\nOMG/KRW"=>19, "이더리움클래식\nETC/KRW"=>20, "네오\nNEO/KRW"=>21, "스토리지\nSTORJ/KRW"=>22, "비트코인골드\nBTG/KRW"=>23, "메탈\nMTL/KRW"=>24, "모네로\nXMR/KRW"=>25, "웨이브\nWAVES/KRW"=>26, "아크\nARK/KRW"=>27, "버트코인\nVTC/KRW"=>28, "리스크\nLSK/KRW"=>29, "어거\nREP/KRW"=>30, "라이트코인\nLTC/KRW"=>31, "피벡스\nPIVX/KRW"=>32, "대시\nDASH/KRW"=>33, "지캐시\nZEC/KRW"=>34, "아더\nARDR/KRW"=>35}

          
          bandList_Array = @watir.tds(:class => 'tit' ).collect(&:text)
          
          puts 'bandList_Array List Count [ '+bandList_Array.length.to_s + ']'
          count = 0 
          
          bandList_Array.slice(0,35)    #=> "c"
      
          bandList_Array.each do |textValue|
             puts textValue
             puts count = count+1
          end
          
          arrayRank = {}
          countValue = 0    
          bandList_Array.each do | value|
             countValue = countValue+1
             arrayRank[value] = countValue
          end
        
          @nowTranValue =  arrayRank          
          puts @nowTranValue
          result = {}
          @beforeTranValue.each {|k, v| result[k] =  @nowTranValue[k] if  @nowTranValue[k] != v }
        
          result2 = result.sort_by{ |x| x.last }.to_h
         
          puts listValue
          puts @beforeTranValue
          puts @nowTranValue 
      
          @beforeTranValue = @nowTranValue   
          
          result2.each do |key, value|
              puts '***************Key ...****************'
              puts key
              puts '***************Value...****************'
              puts value
               
                
          
          end
         
    
     rescue
       self.start 
     puts 'error'
   end 
    
   # {"BCH"=>9399060155, "BTC"=>2603241157, "ETC"=>2164481285, "LTC"=>2164481285, "DASH"=>1038448996, "ETH"=>509666754, "XRP"=>362889257, "QTUM"=>200472265, "ZEC"=>101484164, "XMR"=>90611004}

   
  end
   
end



doTask = CoinVolumnBest.new() 
doTask.start